﻿namespace BookingManagement
{
    partial class Equipments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            logoutbtn = new Button();
            bookingsbtn = new Button();
            userbtn = new Button();
            button1 = new Button();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label1 = new Label();
            enamet = new TextBox();
            quantityt = new TextBox();
            ename = new Label();
            quantity = new Label();
            label5 = new Label();
            categoryDropdown = new ComboBox();
            typet = new TextBox();
            etype = new Label();
            addbtn = new Button();
            editbtn = new Button();
            deletebtn = new Button();
            dataGridView1 = new DataGridView();
            button9 = new Button();
            eid = new Label();
            eidt = new TextBox();
            ebrand = new Label();
            ebrandt = new TextBox();
            searchbtn = new Button();
            searchfieldt = new TextBox();
            panel2 = new Panel();
            equipmentlist = new Label();
            label2 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(logoutbtn);
            panel1.Controls.Add(bookingsbtn);
            panel1.Controls.Add(userbtn);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(241, 655);
            panel1.TabIndex = 2;
            // 
            // logoutbtn
            // 
            logoutbtn.BackColor = Color.Red;
            logoutbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            logoutbtn.Location = new Point(36, 468);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(174, 43);
            logoutbtn.TabIndex = 11;
            logoutbtn.Text = "Logout";
            logoutbtn.UseVisualStyleBackColor = false;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // bookingsbtn
            // 
            bookingsbtn.BackColor = SystemColors.GradientActiveCaption;
            bookingsbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bookingsbtn.Location = new Point(36, 383);
            bookingsbtn.Name = "bookingsbtn";
            bookingsbtn.Size = new Size(174, 43);
            bookingsbtn.TabIndex = 10;
            bookingsbtn.Text = "Bookings";
            bookingsbtn.UseVisualStyleBackColor = false;
            bookingsbtn.Click += bookingsbtn_Click;
            // 
            // userbtn
            // 
            userbtn.BackColor = SystemColors.GradientInactiveCaption;
            userbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userbtn.Location = new Point(36, 302);
            userbtn.Name = "userbtn";
            userbtn.Size = new Size(174, 43);
            userbtn.TabIndex = 9;
            userbtn.Text = "Users";
            userbtn.UseVisualStyleBackColor = false;
            userbtn.Click += userbtn_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.ForestGreen;
            button1.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(36, 220);
            button1.Name = "button1";
            button1.Size = new Size(174, 43);
            button1.TabIndex = 8;
            button1.Text = "Equipment";
            button1.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(36, 79);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 6;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(52, 120);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 5;
            label7.Text = "Nice Service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(66, 41);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 4;
            label6.Text = "Nice Staff";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(289, 15);
            label1.Name = "label1";
            label1.Size = new Size(179, 32);
            label1.TabIndex = 0;
            label1.Text = "Admin Panel";
            // 
            // enamet
            // 
            enamet.Location = new Point(22, 84);
            enamet.Name = "enamet";
            enamet.Size = new Size(164, 23);
            enamet.TabIndex = 1;
            // 
            // quantityt
            // 
            quantityt.Location = new Point(350, 84);
            quantityt.Name = "quantityt";
            quantityt.Size = new Size(96, 23);
            quantityt.TabIndex = 2;
            // 
            // ename
            // 
            ename.AutoSize = true;
            ename.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ename.Location = new Point(22, 62);
            ename.Name = "ename";
            ename.Size = new Size(144, 19);
            ename.TabIndex = 3;
            ename.Text = "EQUIPMENT NAME";
            // 
            // quantity
            // 
            quantity.AutoSize = true;
            quantity.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            quantity.Location = new Point(350, 62);
            quantity.Name = "quantity";
            quantity.Size = new Size(84, 19);
            quantity.TabIndex = 4;
            quantity.Text = "QUANTITY";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Red;
            label5.Location = new Point(776, -3);
            label5.Name = "label5";
            label5.Size = new Size(29, 32);
            label5.TabIndex = 6;
            label5.Text = "x";
            label5.Click += exitbtn_Click;
            // 
            // categoryDropdown
            // 
            categoryDropdown.Font = new Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            categoryDropdown.ForeColor = SystemColors.WindowFrame;
            categoryDropdown.FormattingEnabled = true;
            categoryDropdown.Location = new Point(350, 141);
            categoryDropdown.Name = "categoryDropdown";
            categoryDropdown.Size = new Size(160, 24);
            categoryDropdown.TabIndex = 7;
            categoryDropdown.Text = "Select Category";
            // 
            // typet
            // 
            typet.Location = new Point(22, 142);
            typet.Name = "typet";
            typet.Size = new Size(164, 23);
            typet.TabIndex = 8;
            // 
            // etype
            // 
            etype.AutoSize = true;
            etype.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            etype.Location = new Point(22, 120);
            etype.Name = "etype";
            etype.Size = new Size(132, 19);
            etype.TabIndex = 9;
            etype.Text = "EQUIPMENT TYPE";
            // 
            // addbtn
            // 
            addbtn.BackColor = Color.ForestGreen;
            addbtn.Font = new Font("Century Gothic", 12F);
            addbtn.ForeColor = SystemColors.ButtonFace;
            addbtn.Location = new Point(55, 191);
            addbtn.Name = "addbtn";
            addbtn.Size = new Size(111, 41);
            addbtn.TabIndex = 27;
            addbtn.Text = "Add";
            addbtn.UseVisualStyleBackColor = false;
            addbtn.Click += addbtn_Click;
            // 
            // editbtn
            // 
            editbtn.BackColor = Color.ForestGreen;
            editbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            editbtn.ForeColor = SystemColors.ButtonFace;
            editbtn.Location = new Point(210, 191);
            editbtn.Name = "editbtn";
            editbtn.Size = new Size(111, 41);
            editbtn.TabIndex = 11;
            editbtn.Text = "Edit";
            editbtn.UseVisualStyleBackColor = false;
            editbtn.Click += editbtn_Click;
            // 
            // deletebtn
            // 
            deletebtn.BackColor = Color.Red;
            deletebtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            deletebtn.ForeColor = SystemColors.ButtonFace;
            deletebtn.Location = new Point(55, 238);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new Size(111, 41);
            deletebtn.TabIndex = 12;
            deletebtn.Text = "Delete";
            deletebtn.UseVisualStyleBackColor = false;
            deletebtn.Click += deletebtn_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonFace;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(20, 319);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(748, 315);
            dataGridView1.TabIndex = 14;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // button9
            // 
            button9.BackColor = Color.ForestGreen;
            button9.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button9.ForeColor = SystemColors.ButtonFace;
            button9.Location = new Point(208, 238);
            button9.Name = "button9";
            button9.Size = new Size(111, 41);
            button9.TabIndex = 17;
            button9.Text = "Refresh";
            button9.UseVisualStyleBackColor = false;
            button9.Click += refreshbtn_Click;
            // 
            // eid
            // 
            eid.AutoSize = true;
            eid.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            eid.Location = new Point(208, 62);
            eid.Name = "eid";
            eid.Size = new Size(113, 19);
            eid.TabIndex = 18;
            eid.Text = "EQUIPMENT ID";
            // 
            // eidt
            // 
            eidt.Location = new Point(208, 84);
            eidt.Name = "eidt";
            eidt.Size = new Size(95, 23);
            eidt.TabIndex = 19;
            // 
            // ebrand
            // 
            ebrand.AutoSize = true;
            ebrand.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ebrand.Location = new Point(208, 120);
            ebrand.Name = "ebrand";
            ebrand.Size = new Size(62, 19);
            ebrand.TabIndex = 20;
            ebrand.Text = "BRAND";
            // 
            // ebrandt
            // 
            ebrandt.Location = new Point(208, 142);
            ebrandt.Name = "ebrandt";
            ebrandt.Size = new Size(125, 23);
            ebrandt.TabIndex = 21;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.ForestGreen;
            searchbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            searchbtn.ForeColor = SystemColors.ButtonFace;
            searchbtn.Location = new Point(604, 65);
            searchbtn.Name = "searchbtn";
            searchbtn.Size = new Size(122, 42);
            searchbtn.TabIndex = 22;
            searchbtn.Text = "Search";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // searchfieldt
            // 
            searchfieldt.Location = new Point(584, 113);
            searchfieldt.Name = "searchfieldt";
            searchfieldt.Size = new Size(164, 23);
            searchfieldt.TabIndex = 23;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientActiveCaption;
            panel2.Controls.Add(equipmentlist);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(searchfieldt);
            panel2.Controls.Add(searchbtn);
            panel2.Controls.Add(ebrandt);
            panel2.Controls.Add(ebrand);
            panel2.Controls.Add(eidt);
            panel2.Controls.Add(eid);
            panel2.Controls.Add(button9);
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(deletebtn);
            panel2.Controls.Add(editbtn);
            panel2.Controls.Add(addbtn);
            panel2.Controls.Add(etype);
            panel2.Controls.Add(typet);
            panel2.Controls.Add(categoryDropdown);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(quantity);
            panel2.Controls.Add(ename);
            panel2.Controls.Add(quantityt);
            panel2.Controls.Add(enamet);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(248, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(805, 655);
            panel2.TabIndex = 3;
            // 
            // equipmentlist
            // 
            equipmentlist.AutoSize = true;
            equipmentlist.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            equipmentlist.Location = new Point(323, 297);
            equipmentlist.Name = "equipmentlist";
            equipmentlist.Size = new Size(124, 19);
            equipmentlist.TabIndex = 26;
            equipmentlist.Text = "EQUIPMENT LIST";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(350, 120);
            label2.Name = "label2";
            label2.Size = new Size(123, 19);
            label2.TabIndex = 25;
            label2.Text = "CATEGORY LIST";
            // 
            // Equipments
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1065, 679);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Equipments";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Equipments";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Label label8;
        private Label label7;
        private Label label6;
        private Button logoutbtn;
        private Button bookingsbtn;
        private Button userbtn;
        private Button button1;
        private Label label1;
        private TextBox enamet;
        private TextBox quantityt;
        private Label ename;
        private Label quantity;
        private Label label5;
        private ComboBox categoryDropdown;
        private TextBox typet;
        private Label etype;
        private Button addbtn;
        private Button editbtn;
        private Button deletebtn;
        private DataGridView dataGridView1;
        private Button button9;
        private Label eid;
        private TextBox eidt;
        private Label ebrand;
        private TextBox ebrandt;
        private Button searchbtn;
        private TextBox searchfieldt;
        private Panel panel2;
        private Label equipmentlist;
        private Label label2;
    }
}