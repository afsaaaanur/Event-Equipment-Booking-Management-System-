﻿namespace BookingManagement
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label10 = new Label();
            dataGridView1 = new DataGridView();
            refreshbtn = new Button();
            deletebtn = new Button();
            editbtn = new Button();
            exitbtn = new Label();
            logoutbtn = new Button();
            bookingsbtn = new Button();
            userbtn = new Button();
            panel1 = new Panel();
            button1 = new Button();
            label1 = new Label();
            panel2 = new Panel();
            searchfieldt = new TextBox();
            searchbtn = new Button();
            uphonet = new TextBox();
            uphone = new Label();
            unamet = new TextBox();
            uemail = new Label();
            uemailt = new TextBox();
            uname = new Label();
            uid = new Label();
            uidt = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(36, 79);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 6;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(52, 120);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 5;
            label7.Text = "Nice Service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(66, 41);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 4;
            label6.Text = "Nice Staff";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label10.Location = new Point(365, 232);
            label10.Name = "label10";
            label10.Size = new Size(90, 23);
            label10.TabIndex = 16;
            label10.Text = "USER LIST";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonFace;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(3, 258);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(805, 382);
            dataGridView1.TabIndex = 14;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // refreshbtn
            // 
            refreshbtn.BackColor = Color.ForestGreen;
            refreshbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            refreshbtn.ForeColor = SystemColors.ButtonFace;
            refreshbtn.Location = new Point(498, 92);
            refreshbtn.Name = "refreshbtn";
            refreshbtn.Size = new Size(111, 41);
            refreshbtn.TabIndex = 13;
            refreshbtn.Text = "Refresh";
            refreshbtn.UseVisualStyleBackColor = false;
            refreshbtn.Click += refreshbtn_Click;
            // 
            // deletebtn
            // 
            deletebtn.BackColor = Color.Red;
            deletebtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            deletebtn.ForeColor = SystemColors.ButtonFace;
            deletebtn.Location = new Point(498, 157);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new Size(111, 41);
            deletebtn.TabIndex = 12;
            deletebtn.Text = "Delete";
            deletebtn.UseVisualStyleBackColor = false;
            deletebtn.Click += deletebtn_Click;
            // 
            // editbtn
            // 
            editbtn.BackColor = Color.ForestGreen;
            editbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            editbtn.ForeColor = SystemColors.ButtonFace;
            editbtn.Location = new Point(638, 92);
            editbtn.Name = "editbtn";
            editbtn.Size = new Size(111, 41);
            editbtn.TabIndex = 11;
            editbtn.Text = "Edit";
            editbtn.UseVisualStyleBackColor = false;
            editbtn.Click += editbtn_Click;
            // 
            // exitbtn
            // 
            exitbtn.AutoSize = true;
            exitbtn.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitbtn.ForeColor = Color.Red;
            exitbtn.Location = new Point(776, -3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(29, 32);
            exitbtn.TabIndex = 6;
            exitbtn.Text = "x";
            exitbtn.Click += exitbtn_Click;
            // 
            // logoutbtn
            // 
            logoutbtn.BackColor = Color.Red;
            logoutbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            logoutbtn.Location = new Point(36, 468);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(174, 43);
            logoutbtn.TabIndex = 11;
            logoutbtn.Text = "Logout";
            logoutbtn.UseVisualStyleBackColor = false;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // bookingsbtn
            // 
            bookingsbtn.BackColor = SystemColors.GradientActiveCaption;
            bookingsbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bookingsbtn.Location = new Point(36, 383);
            bookingsbtn.Name = "bookingsbtn";
            bookingsbtn.Size = new Size(174, 43);
            bookingsbtn.TabIndex = 10;
            bookingsbtn.Text = "Bookings";
            bookingsbtn.UseVisualStyleBackColor = false;
            bookingsbtn.Click += bookingsbtn_Click;
            // 
            // userbtn
            // 
            userbtn.BackColor = Color.ForestGreen;
            userbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userbtn.Location = new Point(36, 302);
            userbtn.Name = "userbtn";
            userbtn.Size = new Size(174, 43);
            userbtn.TabIndex = 9;
            userbtn.Text = "Users";
            userbtn.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(logoutbtn);
            panel1.Controls.Add(bookingsbtn);
            panel1.Controls.Add(userbtn);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(241, 655);
            panel1.TabIndex = 4;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.GradientActiveCaption;
            button1.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(36, 220);
            button1.Name = "button1";
            button1.Size = new Size(174, 43);
            button1.TabIndex = 8;
            button1.Text = "Equipment";
            button1.UseVisualStyleBackColor = false;
            button1.Click += equipmentbtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(309, 11);
            label1.Name = "label1";
            label1.Size = new Size(179, 32);
            label1.TabIndex = 0;
            label1.Text = "Admin Panel";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientActiveCaption;
            panel2.Controls.Add(searchfieldt);
            panel2.Controls.Add(searchbtn);
            panel2.Controls.Add(uphonet);
            panel2.Controls.Add(uphone);
            panel2.Controls.Add(unamet);
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(refreshbtn);
            panel2.Controls.Add(deletebtn);
            panel2.Controls.Add(editbtn);
            panel2.Controls.Add(uemail);
            panel2.Controls.Add(uemailt);
            panel2.Controls.Add(exitbtn);
            panel2.Controls.Add(uname);
            panel2.Controls.Add(uid);
            panel2.Controls.Add(uidt);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(label10);
            panel2.Location = new Point(248, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(805, 655);
            panel2.TabIndex = 5;
            // 
            // searchfieldt
            // 
            searchfieldt.Location = new Point(638, 204);
            searchfieldt.Name = "searchfieldt";
            searchfieldt.Size = new Size(127, 23);
            searchfieldt.TabIndex = 22;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.ForestGreen;
            searchbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            searchbtn.ForeColor = SystemColors.ButtonFace;
            searchbtn.Location = new Point(638, 157);
            searchbtn.Name = "searchbtn";
            searchbtn.Size = new Size(111, 41);
            searchbtn.TabIndex = 21;
            searchbtn.Text = "Search";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // uphonet
            // 
            uphonet.Location = new Point(208, 122);
            uphonet.Name = "uphonet";
            uphonet.Size = new Size(163, 23);
            uphonet.TabIndex = 20;
            // 
            // uphone
            // 
            uphone.AutoSize = true;
            uphone.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uphone.Location = new Point(208, 103);
            uphone.Name = "uphone";
            uphone.Size = new Size(95, 19);
            uphone.TabIndex = 19;
            uphone.Text = "PHONE NO.";
            // 
            // unamet
            // 
            unamet.Location = new Point(24, 179);
            unamet.Name = "unamet";
            unamet.Size = new Size(163, 23);
            unamet.TabIndex = 18;
            // 
            // uemail
            // 
            uemail.AutoSize = true;
            uemail.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uemail.Location = new Point(208, 157);
            uemail.Name = "uemail";
            uemail.Size = new Size(54, 19);
            uemail.TabIndex = 9;
            uemail.Text = "EMAIL";
            // 
            // uemailt
            // 
            uemailt.Location = new Point(208, 179);
            uemailt.Name = "uemailt";
            uemailt.Size = new Size(164, 23);
            uemailt.TabIndex = 8;
            // 
            // uname
            // 
            uname.AutoSize = true;
            uname.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uname.Location = new Point(24, 157);
            uname.Name = "uname";
            uname.Size = new Size(90, 19);
            uname.TabIndex = 4;
            uname.Text = "USERNAME";
            // 
            // uid
            // 
            uid.AutoSize = true;
            uid.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uid.Location = new Point(24, 98);
            uid.Name = "uid";
            uid.Size = new Size(63, 19);
            uid.TabIndex = 3;
            uid.Text = "USER ID";
            // 
            // uidt
            // 
            uidt.Location = new Point(24, 120);
            uidt.Name = "uidt";
            uidt.Size = new Size(98, 23);
            uidt.TabIndex = 1;
            // 
            // User
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1065, 679);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "User";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "User";
            Load += User_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label8;
        private Label label7;
        private Label label6;
        private Label label10;
        private DataGridView dataGridView1;
        private Button refreshbtn;
        private Button deletebtn;
        private Button editbtn;
        private Label exitbtn;
        private Button logoutbtn;
        private Button bookingsbtn;
        private Button userbtn;
        private Panel panel1;
        private Button button1;
        private Label label1;
        private Panel panel2;
        private Button searchbtn;
        private TextBox uphonet;
        private Label uphone;
        private TextBox unamet;
        private Label uemail;
        private TextBox uemailt;
        private Label uname;
        private Label uid;
        private TextBox uidt;
        private TextBox searchfieldt;
    }
}