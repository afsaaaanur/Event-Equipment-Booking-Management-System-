﻿namespace BookingManagement
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            panel2 = new Panel();
            registertext = new Label();
            registerbtn = new Button();
            passLabel = new Label();
            exit = new Label();
            exitbtn = new Button();
            loginbtn = new Button();
            admin = new Label();
            upasst = new TextBox();
            unamet = new TextBox();
            label1 = new Label();
            uName = new Label();
            admint = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 426);
            panel1.TabIndex = 0;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(7, 188);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 9;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(23, 229);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 8;
            label7.Text = "Nice Service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(37, 150);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 7;
            label6.Text = "Nice Staff";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientInactiveCaption;
            panel2.Controls.Add(admint);
            panel2.Controls.Add(registertext);
            panel2.Controls.Add(registerbtn);
            panel2.Controls.Add(passLabel);
            panel2.Controls.Add(exit);
            panel2.Controls.Add(exitbtn);
            panel2.Controls.Add(loginbtn);
            panel2.Controls.Add(admin);
            panel2.Controls.Add(upasst);
            panel2.Controls.Add(unamet);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(uName);
            panel2.Location = new Point(208, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(580, 426);
            panel2.TabIndex = 1;
            // 
            // registertext
            // 
            registertext.AutoSize = true;
            registertext.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registertext.Location = new Point(190, 308);
            registertext.Name = "registertext";
            registertext.Size = new Size(206, 19);
            registertext.TabIndex = 11;
            registertext.Text = "No account? sign up now";
            // 
            // registerbtn
            // 
            registerbtn.BackColor = SystemColors.MenuHighlight;
            registerbtn.Font = new Font("Century Gothic", 12F);
            registerbtn.Location = new Point(226, 345);
            registerbtn.Name = "registerbtn";
            registerbtn.Size = new Size(119, 47);
            registerbtn.TabIndex = 10;
            registerbtn.Text = "Register";
            registerbtn.UseVisualStyleBackColor = false;
            registerbtn.Click += registerbtn_Click;
            // 
            // passLabel
            // 
            passLabel.AutoSize = true;
            passLabel.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            passLabel.Location = new Point(120, 202);
            passLabel.Name = "passLabel";
            passLabel.Size = new Size(80, 19);
            passLabel.TabIndex = 9;
            passLabel.Text = "Password";
            // 
            // exit
            // 
            exit.AutoSize = true;
            exit.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exit.ForeColor = Color.Red;
            exit.Location = new Point(559, -3);
            exit.Name = "exit";
            exit.Size = new Size(21, 23);
            exit.TabIndex = 8;
            exit.Text = "x";
            exit.Click += exit_Click;
            // 
            // exitbtn
            // 
            exitbtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            exitbtn.Location = new Point(309, 249);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(108, 33);
            exitbtn.TabIndex = 7;
            exitbtn.Text = "Exit";
            exitbtn.UseVisualStyleBackColor = true;
            exitbtn.Click += exitbtn_Click;
            // 
            // loginbtn
            // 
            loginbtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            loginbtn.Location = new Point(167, 249);
            loginbtn.Name = "loginbtn";
            loginbtn.Size = new Size(108, 33);
            loginbtn.TabIndex = 6;
            loginbtn.Text = "Login";
            loginbtn.UseVisualStyleBackColor = true;
            loginbtn.Click += loginbtn_Click;
            // 
            // admin
            // 
            admin.AutoSize = true;
            admin.BackColor = SystemColors.Info;
            admin.Font = new Font("Century Gothic", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            admin.ForeColor = SystemColors.ActiveCaptionText;
            admin.Location = new Point(318, 99);
            admin.Name = "admin";
            admin.Size = new Size(108, 19);
            admin.TabIndex = 5;
            admin.Text = "Admin Login";
            // 
            // upasst
            // 
            upasst.Location = new Point(226, 202);
            upasst.Name = "upasst";
            upasst.PasswordChar = '*';
            upasst.Size = new Size(166, 23);
            upasst.TabIndex = 4;
            // 
            // unamet
            // 
            unamet.Location = new Point(226, 155);
            unamet.Name = "unamet";
            unamet.Size = new Size(166, 23);
            unamet.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(83, 31);
            label1.Name = "label1";
            label1.Size = new Size(405, 32);
            label1.TabIndex = 2;
            label1.Text = "Booking Management System";
            // 
            // uName
            // 
            uName.AutoSize = true;
            uName.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uName.Location = new Point(120, 156);
            uName.Name = "uName";
            uName.Size = new Size(87, 19);
            uName.TabIndex = 0;
            uName.Text = "Username";
            // 
            // admint
            // 
            admint.AutoSize = true;
            admint.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            admint.Location = new Point(139, 99);
            admint.Name = "admint";
            admint.Size = new Size(173, 16);
            admint.TabIndex = 12;
            admint.Text = "Admin? Click here to login→";
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label uName;
        private Button loginbtn;
        private Label admin;
        private TextBox upasst;
        private TextBox unamet;
        private Label label1;
        private Button exitbtn;
        private Label exit;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label passLabel;
        private Label registertext;
        private Button registerbtn;
        private Label admint;
    }
}