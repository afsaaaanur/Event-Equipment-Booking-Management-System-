﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BookingManagement
{
    public partial class Bookings : Form
    {
        SqlConnection con = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True");

        public Bookings()
        {
            InitializeComponent();
            this.Load += Bookings_Load;
        }

        //FORM LOAD
        private void Bookings_Load(object sender, EventArgs e)
        {
            LoadBookings();
        }

        //LOAD BOOKINGS
        private void LoadBookings()
        {
            try
            {
                if (con.State == ConnectionState.Closed) con.Open();

                string query = @"
                    SELECT 
                    B.BID ,
                    U.UID,          
                    U.UNAME AS Username,
                    C.CNAME AS Category,
                    E.ENAME AS Equipment,
                    BE.Qty AS BookedQuantity,
                    B.BDATE AS BookingStart,
                    B.BEND AS BookingEnd,
                    B.STATUS
                FROM BOOKTB2 B
                INNER JOIN USERTB1 U ON B.UID = U.UID
                INNER JOIN BOOK_EQUIPMENTTB5 BE ON B.BID = BE.BID
                INNER JOIN EQUIPMENTTB4 E ON BE.EID = E.EID
                INNER JOIN CATEGORYTB3 C ON E.CID = C.CID
                ORDER BY B.BID
                ";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //DELETE BOOKING
        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(bidt.Text))
            {
                MessageBox.Show("Select a booking from the table");
                return;
            }

                DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this booking?",
            "Confirm Delete",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning);

            if (result == DialogResult.No)
                return;

            try
            {
                con.Open();

                int bid = Convert.ToInt32(bidt.Text);

                SqlCommand cmdChild = new SqlCommand(
                    "DELETE FROM BOOK_EQUIPMENTTB5 WHERE BID=@bid", con); //child table
                cmdChild.Parameters.AddWithValue("@bid", bid);
                cmdChild.ExecuteNonQuery();

                SqlCommand cmdParent = new SqlCommand(
                    "DELETE FROM BOOKTB2 WHERE BID=@bid", con); //parent table
                cmdParent.Parameters.AddWithValue("@bid", bid);
                cmdParent.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("Booking Deleted Successfully");

                LoadBookings();
                ResetFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //RESET
        private void ResetFields()
        {
            bidt.Clear();

        }

        //REFRESH
        private void refreshbtn_Click(object sender, EventArgs e)
        {
            LoadBookings();
            ResetFields();
        }

        
        //GRID CLICK
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                bidt.Text = dataGridView1.Rows[e.RowIndex].Cells["BID"].Value.ToString();
            }
        }
        private void searchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(searchfieldt.Text))
                {
                    MessageBox.Show("Enter something to search!");
                    return;
                }

                using (SqlConnection con = new SqlConnection(
                   @"Data Source=(LocalDB)\MSSQLLocalDB;
             AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
             Integrated Security=True"))
                {
                    con.Open();

                    string query = @"
                SELECT 
                    B.BID,
                    U.UID,
                    U.UNAME AS Username,
                    C.CNAME AS Category,
                    E.ENAME AS EquipmentName,
                    BE.Qty AS BookedQuantity,
                    B.STATUS
                FROM BOOKTB2 B
                INNER JOIN USERTB1 U ON B.UID = U.UID
                INNER JOIN BOOK_EQUIPMENTTB5 BE ON B.BID = BE.BID
                INNER JOIN EQUIPMENTTB4 E ON BE.EID = E.EID
                INNER JOIN CATEGORYTB3 C ON E.CID = C.CID
                WHERE 
                    U.UNAME LIKE @SEARCH
                    OR E.ENAME LIKE @SEARCH
                    OR E.EBRAND LIKE @SEARCH
                    OR C.CNAME LIKE @SEARCH
                    OR CAST(U.UID AS VARCHAR) LIKE @SEARCH
                    OR CAST(B.BID AS VARCHAR) LIKE @SEARCH
                ORDER BY B.BID
            ";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    { 
                        cmd.Parameters.AddWithValue("@SEARCH", "%" + searchfieldt.Text.Trim() + "%");

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dataGridView1.DataSource = dt;
                        }
                        else
                        {
                            dataGridView1.DataSource = null;
                            MessageBox.Show("No Matching Data Found");
                        }
                    }
                }

                searchfieldt.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error!!\n" + ex.Message, "ERROR");
            }
        }
        //NAVUGATION BUTTONS
        private void logoutbtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to log out?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            Login lg = new Login();
            lg.Show();
            this.Hide();
        }


        private void userbtn_Click(object sender, EventArgs e)
        {
            User u = new User();
            u.Show();
            this.Hide();
        }

        private void equipmentbtn_Click(object sender, EventArgs e)
        {
            Equipments eq = new Equipments();
            eq.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
