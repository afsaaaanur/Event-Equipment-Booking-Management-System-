﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace BookingManagement
{
    public partial class CreateBookings : Form
    {
        SqlConnection con = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True");

        int selectedBID = -1;
        int uid = Session.UserId;

        public CreateBookings()
        {
            InitializeComponent();
            this.Load += CreateBookings_Load;
        }

        private void CreateBookings_Load(object sender, EventArgs e)
        {
            LoadCategories();
            LoadUserBookings();
            categoryt.SelectedIndexChanged += Categoryt_SelectedIndexChanged;

            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
        }

        //LOAD CATEGORIES
        void LoadCategories()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT CID, CNAME FROM CATEGORYTB3", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            DataRow dr = dt.NewRow();
            dr["CID"] = 0; 
            dr["CNAME"] = "Please select a category";
            dt.Rows.InsertAt(dr, 0);

            categoryt.DataSource = dt;
            categoryt.DisplayMember = "CNAME";
            categoryt.ValueMember = "CID";
            categoryt.SelectedIndex = 0;
        }

        private void Categoryt_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (categoryt.SelectedValue == null || categoryt.SelectedValue is DataRowView) return;

            string q = "SELECT EID, ENAME FROM EQUIPMENTTB4 WHERE CID=@cid";

            SqlDataAdapter da = new SqlDataAdapter(q, con);
            da.SelectCommand.Parameters.AddWithValue("@cid", categoryt.SelectedValue);
            DataTable dt = new DataTable();
            da.Fill(dt);

            equipmentt.DataSource = dt;
            equipmentt.DisplayMember = "ENAME";
            equipmentt.ValueMember = "EID";
        }

        // LOAD BOOKINGS
        void LoadUserBookings()
        {
            SqlDataAdapter da = new SqlDataAdapter(
                @"SELECT 
            B.BID,
            B.BDATE AS StartDate,
            B.BEND AS EndDate,
            E.ENAME AS EquipmentName,
            E.EBRAND AS Brand,
            C.CNAME AS Category,
            BE.Qty AS BookedQuantity,
            B.STATUS
          FROM BOOKTB2 B
          JOIN BOOK_EQUIPMENTTB5 BE ON B.BID = BE.BID
          JOIN EQUIPMENTTB4 E ON BE.EID = E.EID
          JOIN CATEGORYTB3 C ON E.CID = C.CID
          WHERE B.UID = @uid", con);
            da.SelectCommand.Parameters.AddWithValue("@uid", uid);

            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        //ADD BOOKING
        private void addbtn_Click(object sender, EventArgs e)
        {
            if (equipmentt.SelectedValue == null || quantityt.Value <= 0)
            {
                MessageBox.Show("Select equipment and valid quantity.");
                return;
            }

            con.Open();

            //Check available stock
            SqlCommand checkStock = new SqlCommand(
                "SELECT EQUANTITY FROM EQUIPMENTTB4 WHERE EID=@eid", con);
            checkStock.Parameters.AddWithValue("@eid", equipmentt.SelectedValue);

            int availableStock = Convert.ToInt32(checkStock.ExecuteScalar());

            if (quantityt.Value > availableStock)
            {
                MessageBox.Show($"Only {availableStock} item(s) available!");
                con.Close();
                return;
            }

            //Inserting in BOOKTB2
            SqlCommand insertBooking = new SqlCommand(
                "INSERT INTO BOOKTB2 (UID, BDATE, BEND, STATUS) VALUES (@uid, @s, @e, 'Pending'); SELECT SCOPE_IDENTITY();", con);
            insertBooking.Parameters.AddWithValue("@uid", uid);
            insertBooking.Parameters.AddWithValue("@s", dateTimePicker1.Value);
            insertBooking.Parameters.AddWithValue("@e", dateTimePicker2.Value);

            int bid = Convert.ToInt32(insertBooking.ExecuteScalar());

            //equipment and quantity
            SqlCommand insertEquip = new SqlCommand(
                "INSERT INTO BOOK_EQUIPMENTTB5 (BID, EID, Qty) VALUES (@bid, @eid, @q)", con);
            insertEquip.Parameters.AddWithValue("@bid", bid);
            insertEquip.Parameters.AddWithValue("@eid", equipmentt.SelectedValue);
            insertEquip.Parameters.AddWithValue("@q", quantityt.Value);
            insertEquip.ExecuteNonQuery();

            //DECREMENT EQUIPMENT STOCK 
            SqlCommand updateStock = new SqlCommand(
                "UPDATE EQUIPMENTTB4 SET EQUIPMENTTB4.EQUANTITY = EQUIPMENTTB4.EQUANTITY - @q WHERE EID=@eid", con);
            updateStock.Parameters.AddWithValue("@q", quantityt.Value);
            updateStock.Parameters.AddWithValue("@eid", equipmentt.SelectedValue);
            updateStock.ExecuteNonQuery();

            con.Close();

            LoadUserBookings();
            MessageBox.Show("Booking added as Pending.");
        }
        //EDIT BOOKING 
        private void editbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            string status = dataGridView1.CurrentRow.Cells["STATUS"].Value.ToString();
            if (status != "Pending")
            {
                MessageBox.Show("Confirmed bookings cannot be edited.");
                return;
            }

            if (categoryt.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a category first!");
                return;
            }

            if (equipmentt.SelectedIndex == -1)
            {
                MessageBox.Show("Please select equipment!");
                return;
            }

            if (quantityt.Value <= 0)
            {
                MessageBox.Show("Quantity must be at least 1!");
                return;
            }

            selectedBID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["BID"].Value);

            try
            {
                con.Open();

                // Get current booking qty and EID
                SqlCommand getOldQtyCmd = new SqlCommand(
                    "SELECT Qty, EID FROM BOOK_EQUIPMENTTB5 WHERE BID=@bid", con);
                getOldQtyCmd.Parameters.AddWithValue("@bid", selectedBID);

                SqlDataReader reader = getOldQtyCmd.ExecuteReader();
                if (!reader.Read())
                {
                    MessageBox.Show("Booking equipment not found.");
                    reader.Close();
                    con.Close();
                    return;
                }

                int oldQty = Convert.ToInt32(reader["Qty"]);
                int eid = Convert.ToInt32(reader["EID"]);
                reader.Close();

                // Calculate new qty
                int newQty = oldQty + (int)quantityt.Value; // increment by numericupdown 

                // Restore old stock
                SqlCommand restoreStockCmd = new SqlCommand(
                    "UPDATE EQUIPMENTTB4 SET EQUIPMENTTB4.EQUANTITY = EQUIPMENTTB4.EQUANTITY + @oldQty WHERE EID=@eid", con);
                restoreStockCmd.Parameters.AddWithValue("@oldQty", oldQty);
                restoreStockCmd.Parameters.AddWithValue("@eid", eid);
                restoreStockCmd.ExecuteNonQuery();

                // Check stock again after restore
                SqlCommand checkStockCmd = new SqlCommand(
                    "SELECT EQUANTITY FROM EQUIPMENTTB4 WHERE EID=@eid", con);
                checkStockCmd.Parameters.AddWithValue("@eid", eid);
                int availableStock = Convert.ToInt32(checkStockCmd.ExecuteScalar());

                if (quantityt.Value > availableStock)
                {
                    MessageBox.Show($"Only {availableStock} item(s) available!");
                    con.Close();
                    return;
                }

                // Update booking qty
                SqlCommand updateBookingQty = new SqlCommand(
                    "UPDATE BOOK_EQUIPMENTTB5 SET Qty=@qty WHERE BID=@bid", con);
                updateBookingQty.Parameters.AddWithValue("@qty", quantityt.Value);
                updateBookingQty.Parameters.AddWithValue("@bid", selectedBID);
                updateBookingQty.ExecuteNonQuery();

                // Deduct new quantity
                SqlCommand deductStockCmd = new SqlCommand(
                    "UPDATE EQUIPMENTTB4 SET EQUIPMENTTB4.EQUANTITY = EQUIPMENTTB4.EQUANTITY - @qty WHERE EID=@eid", con);
                deductStockCmd.Parameters.AddWithValue("@qty", quantityt.Value);
                deductStockCmd.Parameters.AddWithValue("@eid", eid);
                deductStockCmd.ExecuteNonQuery();
                con.Close();

                LoadUserBookings();
                MessageBox.Show("Pending booking updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                if (con.State == ConnectionState.Open) con.Close();
            }
        }



        // CONFIRM BOOKING 
        private void confirmbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            string status = dataGridView1.CurrentRow.Cells["STATUS"].Value.ToString();
            if (status != "Pending") return;

            int bid = Convert.ToInt32(dataGridView1.CurrentRow.Cells["BID"].Value);

            con.Open();

            SqlCommand confirm = new SqlCommand(
                "UPDATE BOOKTB2 SET STATUS='Confirmed' WHERE BID=@bid", con);
            confirm.Parameters.AddWithValue("@bid", bid);
            confirm.ExecuteNonQuery();

            con.Close();
            LoadUserBookings();
            MessageBox.Show("Booking confirmed.");
        }
        // ================= NAVIGATION =================

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void userprofilebtn_Click(object sender, EventArgs e)
        {
            UserProfile up = new UserProfile();
            up.Show();
            this.Hide();
        }

        private void cataloguebtn_Click(object sender, EventArgs e)
        {
            Catalogue c = new Catalogue();
            c.Show();
            this.Hide();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to log out?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            Login lg = new Login();
            lg.Show();
            this.Hide();
        }
    }
}
