﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace BookingManagement
{
    public partial class UserProfile : Form
    {
        private readonly string connectionString =
            @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True";

        public UserProfile()
        {
            InitializeComponent();
            this.Load += UserProfile_Load;
        }

        // FORM LOAD
        private void UserProfile_Load(object sender, EventArgs e)
        {
            LoadUserProfile();
        }

        // LOAD USER PROFILE
        private void LoadUserProfile()
        {

            if (Session.UserId <= 0)
            {
                MessageBox.Show("Session expired. Please login again.");
                Login login = new Login();
                login.Show();
                this.Hide();
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string query = @"
                                    SELECT UID,
                                           UNAME,
                                           UPHONE,
                                           UEMAIL,
                                           UPASS
                                    FROM USERTB1
                                    WHERE UID = @userId";


                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@userId", Session.UserId);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                uidt.Text = reader["UID"].ToString();
                                unamet.Text = reader["UNAME"].ToString();
                                uphonet.Text = reader["UPHONE"].ToString();
                                uemailt.Text = reader["UEMAIL"].ToString();
                                upasst.Text = reader["UPASS"].ToString();

                            }
                            else
                            {
                                MessageBox.Show("User not found.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading profile:\n" + ex.Message);
            }
        }

        //UPDATE
        private void editbtn_Click(object sender, EventArgs e)
        {
            if (Session.UserId <= 0)
            {
                MessageBox.Show("Session expired.");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string query = @"UPDATE USERTB1 
                                     SET UNAME=@name,
                                         UPHONE=@phone,
                                         UEMAIL=@email,
                                         UPASS=@password
                                     WHERE UID=@id";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", Session.UserId);
                        cmd.Parameters.AddWithValue("@name", unamet.Text.Trim());
                        cmd.Parameters.AddWithValue("@phone", uphonet.Text.Trim());
                        cmd.Parameters.AddWithValue("@email", uemailt.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", upasst.Text.Trim());

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Profile updated successfully.");
                LoadUserProfile();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed:\n" + ex.Message);
            }
        }

        /*// DELETE 
        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (Session.UserId <= 0)
                return;

            DialogResult confirm = MessageBox.Show(
                "Are you sure you want to delete your account?",
                "Confirm",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes)
                return;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string query = "DELETE FROM USERTB1 WHERE UID=@id";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", Session.UserId);
                        cmd.ExecuteNonQuery();
                    }
                }

                Session.UserId = 0;
                MessageBox.Show("Account deleted.");

                Login login = new Login();
                login.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete failed:\n" + ex.Message);
            }
        }
        */
        //NAVIGATION
        private void bookingbtn_Click(object sender, EventArgs e)
        {
            Catalogue cat = new Catalogue();
            cat.Show();
            this.Hide();
        }

        private void equipmentcatbtn_Click(object sender, EventArgs e)
        {
            Equipments eq = new Equipments();
            eq.Show();
            this.Hide();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            Session.UserId = 0;

            DialogResult result = MessageBox.Show(
                "Are you sure you want to log out?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            Login lg = new Login();
            lg.Show();
            this.Hide();
        }

        private void refreshbtn_Click(object sender, EventArgs e)
        {
            LoadUserProfile();
        }

        private void createbtn_Click(object sender, EventArgs e)
        {
            CreateBookings cb = new CreateBookings();
            cb.Show();
            this.Hide();
        }

        private void cataloguebtn_Click(object sender, EventArgs e)
        {
            Catalogue c = new Catalogue();
            c.Show();
            this.Hide();
        }
    }
}
