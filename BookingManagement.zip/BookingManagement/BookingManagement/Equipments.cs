﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BookingManagement
{
    public partial class Equipments : Form
    {
        SqlConnection con = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True");

        public Equipments()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Equipments_Load);

        }

        // FORM LOAD 
        private void Equipments_Load(object sender, EventArgs e)
        {
            EnsureDefaultCategories();
            LoadCategories();
            LoadEquipment();
        }

        //INSERT CATEGORIES
        private void EnsureDefaultCategories()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string checkQuery = "SELECT COUNT(*) FROM CATEGORYTB3";
                SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                int count = (int)checkCmd.ExecuteScalar();

                if (count == 0)
                {
                    string insertQuery = @"INSERT INTO CATEGORYTB3 (CNAME) VALUES('Audio Equipment'),('Visual & Display Equipment'),('Photography & Video Equipment')";

                    SqlCommand insertCmd = new SqlCommand(insertQuery, con);
                    insertCmd.ExecuteNonQuery();
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //LOAD CATEGORIES
        private void LoadCategories()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string query = "SELECT CID, CNAME FROM CATEGORYTB3";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                con.Close();

                DataRow dr = dt.NewRow();
                dr["CID"] = 0;
                dr["CNAME"] = "Please Select a Category";
                dt.Rows.InsertAt(dr, 0);

                categoryDropdown.DataSource = dt;
                categoryDropdown.DisplayMember = "CNAME";
                categoryDropdown.ValueMember = "CID";
                categoryDropdown.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //LOAD EQUIPMENT 
        private void LoadEquipment()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string query = @" SELECT 
                                    E.EID, E.ENAME AS EquipmentName,
                                    E.ETYPE AS Type,
                                    E.EBRAND AS Brand,  
                                    E.EQUANTITY AS Quantity, 
                                    E.CID, C.CNAME AS CategoryName 
                                        FROM EQUIPMENTTB4 
                                        E INNER JOIN CATEGORYTB3 C ON E.CID = C.CID";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        // ADD BUTTON
        private void addbtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(enamet.Text) ||
                    string.IsNullOrWhiteSpace(typet.Text) ||
                    string.IsNullOrWhiteSpace(ebrandt.Text) ||
                    string.IsNullOrWhiteSpace(quantityt.Text))
                {
                    MessageBox.Show("All fields are required!");
                    return;
                }


                if (categoryDropdown.SelectedIndex == 0)
                {
                    MessageBox.Show("Please select a valid category!");
                    categoryDropdown.Focus();
                    return;
                }
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string query = @"INSERT INTO EQUIPMENTTB4 (ENAME, ETYPE, EBRAND, EQUANTITY, CID)VALUES (@ename, @etype, @ebrand, @quantity, @cid)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ename", enamet.Text.Trim());
                cmd.Parameters.AddWithValue("@etype", typet.Text.Trim());
                cmd.Parameters.AddWithValue("@ebrand", ebrandt.Text.Trim());
                cmd.Parameters.AddWithValue("@quantity", int.Parse(quantityt.Text.Trim()));
                cmd.Parameters.AddWithValue("@cid", categoryDropdown.SelectedValue);

                cmd.ExecuteNonQuery();
                con.Close();

                LoadEquipment();
                ResetFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //EDIT BUTTON
        private void editbtn_Click(object sender, EventArgs e)
        {
            if (eidt.Text == "")
            {
                MessageBox.Show("Select Equipment First");
                return;
            }

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string query = @"UPDATE EQUIPMENTTB4 
                         SET ENAME=@ename,
                             ETYPE=@etype,
                             EBRAND=@ebrand,
                             EQUANTITY=@quantity,
                             CID=@cid
                         WHERE EID=@eid";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@eid", eidt.Text);
                cmd.Parameters.AddWithValue("@ename", enamet.Text.Trim());
                cmd.Parameters.AddWithValue("@etype", typet.Text.Trim());
                cmd.Parameters.AddWithValue("@ebrand", ebrandt.Text.Trim());
                cmd.Parameters.AddWithValue("@quantity", int.Parse(quantityt.Text.Trim()));
                cmd.Parameters.AddWithValue("@cid", categoryDropdown.SelectedValue);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Equipment Updated");

                LoadEquipment();
                ResetFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //DELETE BUTTON
        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (eidt.Text == "")
            {
                MessageBox.Show("Enter Equipment ID");
                return;
            }

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string query = "DELETE FROM EQUIPMENTTB4 WHERE EID=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", eidt.Text);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Equipment Deleted");

                LoadEquipment();
                ResetFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //GRID CLICK 
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                eidt.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                enamet.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                typet.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                ebrandt.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                quantityt.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();

                categoryDropdown.SelectedValue =
                    dataGridView1.Rows[e.RowIndex].Cells[5].Value;
            }
        }
        //  SEARCH 
        private void searchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string query = @"SELECT E.EID, E.ENAME, E.ETYPE, E.EBRAND, E.EQUANTITY, E.CID, C.CNAME
                         FROM EQUIPMENTTB4 E
                         INNER JOIN CATEGORYTB3 C ON E.CID = C.CID
                         WHERE E.ENAME LIKE @search + '%' 
                            OR CAST(E.EID AS VARCHAR) LIKE @search + '%'";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@search", searchfieldt.Text.Trim());

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                    dataGridView1.DataSource = dt;
                else
                    MessageBox.Show("No Matching Data Found");

                con.Close();
                searchfieldt.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error");
            }
        }

        // RESET 
        private void ResetFields()
        {
            eidt.Clear();
            enamet.Clear();
            typet.Clear();
            ebrandt.Clear();
            quantityt.Clear();
            categoryDropdown.SelectedIndex = 0;
        }
        // REFRESH
        private void refreshbtn_Click(object sender, EventArgs e)
        {
            LoadEquipment();
            searchfieldt.Clear();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void userbtn_Click(object sender, EventArgs e)
        {
            User u = new User();
            u.Show();
            this.Hide();
        }

        private void bookingsbtn_Click(object sender, EventArgs e)
        {
            Bookings b = new Bookings();
            b.Show();
            this.Hide();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                 "Are you sure you want to log out?",
                 "Confirm Logout",
                 MessageBoxButtons.YesNo,
                 MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            Login lg = new Login();
            lg.Show();
            this.Hide();
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
