﻿namespace BookingManagement
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            uPhoneNot = new TextBox();
            uPhnNo = new Label();
            uemailt = new TextBox();
            uEmail = new Label();
            uidt = new TextBox();
            uId = new Label();
            uPass = new Label();
            exit = new Label();
            backbtn = new Button();
            registerbtn = new Button();
            uPasst = new TextBox();
            unamet = new TextBox();
            label1 = new Label();
            uName = new Label();
            panel1 = new Panel();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientInactiveCaption;
            panel2.Controls.Add(uPhoneNot);
            panel2.Controls.Add(uPhnNo);
            panel2.Controls.Add(uemailt);
            panel2.Controls.Add(uEmail);
            panel2.Controls.Add(uidt);
            panel2.Controls.Add(uId);
            panel2.Controls.Add(uPass);
            panel2.Controls.Add(exit);
            panel2.Controls.Add(backbtn);
            panel2.Controls.Add(registerbtn);
            panel2.Controls.Add(uPasst);
            panel2.Controls.Add(unamet);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(uName);
            panel2.Location = new Point(208, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(580, 426);
            panel2.TabIndex = 3;
            // 
            // uPhoneNot
            // 
            uPhoneNot.Location = new Point(261, 231);
            uPhoneNot.Name = "uPhoneNot";
            uPhoneNot.Size = new Size(166, 23);
            uPhoneNot.TabIndex = 15;
            // 
            // uPhnNo
            // 
            uPhnNo.AutoSize = true;
            uPhnNo.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uPhnNo.Location = new Point(121, 235);
            uPhnNo.Name = "uPhnNo";
            uPhnNo.Size = new Size(88, 19);
            uPhnNo.TabIndex = 14;
            uPhnNo.Text = "Phone No.";
            // 
            // uemailt
            // 
            uemailt.Location = new Point(261, 184);
            uemailt.Name = "uemailt";
            uemailt.Size = new Size(166, 23);
            uemailt.TabIndex = 13;
            // 
            // uEmail
            // 
            uEmail.AutoSize = true;
            uEmail.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uEmail.Location = new Point(122, 188);
            uEmail.Name = "uEmail";
            uEmail.Size = new Size(52, 19);
            uEmail.TabIndex = 12;
            uEmail.Text = "Email";
            // 
            // uidt
            // 
            uidt.Location = new Point(261, 90);
            uidt.Name = "uidt";
            uidt.ReadOnly = true;
            uidt.Size = new Size(166, 23);
            uidt.TabIndex = 11;
            // 
            // uId
            // 
            uId.AutoSize = true;
            uId.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uId.Location = new Point(122, 94);
            uId.Name = "uId";
            uId.Size = new Size(59, 19);
            uId.TabIndex = 10;
            uId.Text = "User ID";
            // 
            // uPass
            // 
            uPass.AutoSize = true;
            uPass.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uPass.Location = new Point(122, 286);
            uPass.Name = "uPass";
            uPass.Size = new Size(80, 19);
            uPass.TabIndex = 9;
            uPass.Text = "Password";
            // 
            // exit
            // 
            exit.AutoSize = true;
            exit.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exit.ForeColor = Color.Red;
            exit.Location = new Point(559, -3);
            exit.Name = "exit";
            exit.Size = new Size(21, 23);
            exit.TabIndex = 8;
            exit.Text = "x";
            exit.Click += exit_Click;
            // 
            // backbtn
            // 
            backbtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            backbtn.Location = new Point(304, 346);
            backbtn.Name = "backbtn";
            backbtn.Size = new Size(108, 33);
            backbtn.TabIndex = 7;
            backbtn.Text = "Back";
            backbtn.UseVisualStyleBackColor = true;
            backbtn.Click += backbtn_Click;
            // 
            // registerbtn
            // 
            registerbtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            registerbtn.Location = new Point(162, 346);
            registerbtn.Name = "registerbtn";
            registerbtn.Size = new Size(108, 33);
            registerbtn.TabIndex = 6;
            registerbtn.Text = "Register";
            registerbtn.UseVisualStyleBackColor = true;
            registerbtn.Click += registerbtn_Click;
            // 
            // uPasst
            // 
            uPasst.Location = new Point(261, 282);
            uPasst.Name = "uPasst";
            uPasst.Size = new Size(166, 23);
            uPasst.TabIndex = 4;
            // 
            // unamet
            // 
            unamet.Location = new Point(261, 133);
            unamet.Name = "unamet";
            unamet.Size = new Size(166, 23);
            unamet.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(93, 11);
            label1.Name = "label1";
            label1.Size = new Size(405, 32);
            label1.TabIndex = 2;
            label1.Text = "Booking Management System";
            // 
            // uName
            // 
            uName.AutoSize = true;
            uName.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uName.Location = new Point(121, 137);
            uName.Name = "uName";
            uName.Size = new Size(87, 19);
            uName.TabIndex = 0;
            uName.Text = "Username";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 426);
            panel1.TabIndex = 2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(7, 188);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 9;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(23, 229);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 8;
            label7.Text = "Nice Service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(37, 150);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 7;
            label6.Text = "Nice Staff";
            // 
            // Registration
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Registration";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registration";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Label uPass;
        private Label exit;
        private Button backbtn;
        private Button registerbtn;
        private TextBox uPasst;
        private TextBox unamet;
        private Label label1;
        private Label uName;
        private Panel panel1;
        private Label label8;
        private Label label7;
        private Label label6;
        private TextBox uPhoneNot;
        private Label uPhnNo;
        private TextBox uemailt;
        private Label uEmail;
        private TextBox uidt;
        private Label uId;
    }
}