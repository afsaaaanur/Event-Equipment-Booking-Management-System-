﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookingManagement
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            admin.Click += admin_Click;
            
        }
        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void admin_Click(object sender, EventArgs e)
        {

            AdminLogin adminForm = new AdminLogin();
            adminForm.Show();
            this.Hide();
        }
        //REGISTER BUTTON
        private void registerbtn_Click(object sender, EventArgs e)
        {
            Registration regForm = new Registration();
            regForm.Show();
            this.Hide();
        }

       /* private void admin_Click_1(object sender, EventArgs e)
        {
            AdminLogin adminForm = new AdminLogin();
            adminForm.Show();
            this.Hide();
        }
       */
        private void loginbtn_Click(object sender, EventArgs e)
        {
            string username = unamet.Text.Trim();
            string password = upasst.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Enter username and password!");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(
                    @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True"))
                {
                    con.Open();

                    string query = @"SELECT UID FROM USERTB1 
                             WHERE UNAME=@username AND UPASS=@password";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);


                        object result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            int uid = Convert.ToInt32(result);


                            Session.UserId = uid;

                            UserProfile up = new UserProfile();
                            up.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Login failed: " + ex.Message);
            }
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
