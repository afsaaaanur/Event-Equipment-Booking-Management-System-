﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookingManagement
{
    public partial class AdminLogin : Form
    {
        private ErrorProvider errorProviderUser;
        private ErrorProvider errorProviderPass;

        public AdminLogin()
        {
            InitializeComponent();

            errorProviderUser = new ErrorProvider();
            errorProviderPass = new ErrorProvider();
        }

        //VALIDATION
        private bool ValidateInputs()
        {
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(unamet.Text))
            {
                errorProviderUser.SetError(unamet, "Username cannot be empty");
                isValid = false;
            }
            else
            {
                errorProviderUser.Clear();
            }

            if (string.IsNullOrWhiteSpace(upasst.Text))
            {
                errorProviderPass.SetError(upasst, "Password cannot be empty");
                isValid = false;
            }
            else
            {
                errorProviderPass.Clear();
            }

            return isValid;
        }

        //LOGIN
        private void loginbtn_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs())
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error");
                return;
            }

            // Static admin credentials
            const string adminUsername = "admin";
            const string adminPassword = "admin123";

            if (unamet.Text == adminUsername && upasst.Text == adminPassword)
            {
                MessageBox.Show("Login Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                User u = new User();
                u.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Invalid username or password!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        //BACK
        private void backbtn_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            lg.Show();
            this.Hide();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

