﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BookingManagement
{
    public partial class Registration : Form
    {
        string emailPattern = @"^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-.\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$";
        string phonenoPattern = @"^01\d{9}$";

        SqlConnection con = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True");

        public Registration()
        {
            InitializeComponent();
            
        }

        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(unamet.Text) ||
                string.IsNullOrWhiteSpace(uemailt.Text) ||
                string.IsNullOrWhiteSpace(uPhoneNot.Text) ||
                string.IsNullOrWhiteSpace(uPasst.Text))
            {
                MessageBox.Show("All fields are required");
                return false;
            }

            if (!Regex.IsMatch(uemailt.Text, emailPattern))
            {
                MessageBox.Show("Invalid email format");
                return false;
            }
            if (!Regex.IsMatch(uPhoneNot.Text, phonenoPattern))
            {
                MessageBox.Show("Phone number must start with 01 and be exactly 11 digits.");
                return false;
            }


            return true;
        }


//REGISTRATION BUTTON
        private void registerbtn_Click(object sender, EventArgs e)
        {
            if (!ValidateFields()) return;

            try
            {
                con.Open();

                string query = @"
            INSERT INTO USERTB1 (UNAME, UPHONE, UEMAIL, UPASS)
            VALUES (@name, @phone, @email, @pass);
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", unamet.Text);
                cmd.Parameters.AddWithValue("@phone", uPhoneNot.Text);
                cmd.Parameters.AddWithValue("@email", uemailt.Text);
                cmd.Parameters.AddWithValue("@pass", uPasst.Text);

                int newUserId = (int)cmd.ExecuteScalar();

                con.Close();
                uidt.Text = newUserId.ToString();

                MessageBox.Show("Registered successfully! Your User ID is: " + newUserId);

                unamet.Clear();
                uemailt.Clear();
                uPhoneNot.Clear();
                uPasst.Clear();

                //Application.DoEvents();//prevent ui from freezing

                Login lg = new Login();
                lg.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Registration failed: " + ex.Message);
            }
        }
//BACK BUTTON
        private void backbtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                 "Are you sure you want to log out?",
                 "Confirm Logout",
                 MessageBoxButtons.YesNo,
                 MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            Login lg = new Login();
            lg.Show();
            this.Hide();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
