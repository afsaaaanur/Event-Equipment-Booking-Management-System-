﻿namespace BookingManagement
{
    partial class UserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            createbtn = new Button();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            cataloguebtn = new Button();
            logoutbtn = new Button();
            userprfilebtn = new Button();
            label1 = new Label();
            exitbtn = new Label();
            uidt = new TextBox();
            uid = new Label();
            uname = new Label();
            uemailt = new TextBox();
            uemail = new Label();
            editbtn = new Button();
            unamet = new TextBox();
            uphone = new Label();
            uphonet = new TextBox();
            panel2 = new Panel();
            upass = new Label();
            upasst = new TextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(createbtn);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(cataloguebtn);
            panel1.Controls.Add(logoutbtn);
            panel1.Controls.Add(userprfilebtn);
            panel1.Location = new Point(-1, -7);
            panel1.Name = "panel1";
            panel1.Size = new Size(246, 655);
            panel1.TabIndex = 6;
            // 
            // createbtn
            // 
            createbtn.BackColor = SystemColors.GradientActiveCaption;
            createbtn.Font = new Font("Century Gothic", 12F);
            createbtn.Location = new Point(33, 292);
            createbtn.Name = "createbtn";
            createbtn.Size = new Size(174, 37);
            createbtn.TabIndex = 16;
            createbtn.Text = "Create Booking";
            createbtn.UseVisualStyleBackColor = false;
            createbtn.Click += createbtn_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(33, 54);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 15;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(49, 95);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 14;
            label7.Text = "Nice Service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(63, 16);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 13;
            label6.Text = "Nice Staff";
            // 
            // cataloguebtn
            // 
            cataloguebtn.BackColor = SystemColors.GradientActiveCaption;
            cataloguebtn.Font = new Font("Century Gothic", 12F);
            cataloguebtn.Location = new Point(33, 222);
            cataloguebtn.Name = "cataloguebtn";
            cataloguebtn.Size = new Size(174, 53);
            cataloguebtn.TabIndex = 12;
            cataloguebtn.Text = "Equipment Catalogue";
            cataloguebtn.UseVisualStyleBackColor = false;
            cataloguebtn.Click += cataloguebtn_Click;
            // 
            // logoutbtn
            // 
            logoutbtn.BackColor = Color.Red;
            logoutbtn.BackgroundImageLayout = ImageLayout.None;
            logoutbtn.Font = new Font("Century Gothic", 12F);
            logoutbtn.ForeColor = Color.White;
            logoutbtn.Location = new Point(33, 409);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(174, 43);
            logoutbtn.TabIndex = 11;
            logoutbtn.Text = "Logout";
            logoutbtn.UseVisualStyleBackColor = false;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // userprfilebtn
            // 
            userprfilebtn.BackColor = Color.ForestGreen;
            userprfilebtn.Font = new Font("Century Gothic", 12F);
            userprfilebtn.Location = new Point(33, 162);
            userprfilebtn.Name = "userprfilebtn";
            userprfilebtn.Size = new Size(174, 43);
            userprfilebtn.TabIndex = 9;
            userprfilebtn.Text = "User Profile";
            userprfilebtn.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(163, 26);
            label1.Name = "label1";
            label1.Size = new Size(156, 32);
            label1.TabIndex = 0;
            label1.Text = "User Profile";
            // 
            // exitbtn
            // 
            exitbtn.AutoSize = true;
            exitbtn.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitbtn.ForeColor = Color.Red;
            exitbtn.Location = new Point(776, -3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(29, 32);
            exitbtn.TabIndex = 6;
            exitbtn.Text = "x";
            // 
            // uidt
            // 
            uidt.Location = new Point(412, 73);
            uidt.Name = "uidt";
            uidt.ReadOnly = true;
            uidt.Size = new Size(63, 23);
            uidt.TabIndex = 22;
            // 
            // uid
            // 
            uid.AutoSize = true;
            uid.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uid.Location = new Point(412, 51);
            uid.Name = "uid";
            uid.Size = new Size(63, 19);
            uid.TabIndex = 23;
            uid.Text = "USER ID";
            // 
            // uname
            // 
            uname.AutoSize = true;
            uname.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uname.Location = new Point(56, 89);
            uname.Name = "uname";
            uname.Size = new Size(90, 19);
            uname.TabIndex = 24;
            uname.Text = "USERNAME";
            // 
            // uemailt
            // 
            uemailt.Location = new Point(56, 299);
            uemailt.Name = "uemailt";
            uemailt.Size = new Size(302, 23);
            uemailt.TabIndex = 25;
            // 
            // uemail
            // 
            uemail.AutoSize = true;
            uemail.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uemail.Location = new Point(56, 278);
            uemail.Name = "uemail";
            uemail.Size = new Size(54, 19);
            uemail.TabIndex = 26;
            uemail.Text = "EMAIL";
            // 
            // editbtn
            // 
            editbtn.BackColor = Color.ForestGreen;
            editbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            editbtn.ForeColor = SystemColors.ButtonFace;
            editbtn.Location = new Point(452, 375);
            editbtn.Name = "editbtn";
            editbtn.Size = new Size(112, 74);
            editbtn.TabIndex = 27;
            editbtn.Text = "Edit your profile";
            editbtn.UseVisualStyleBackColor = false;
            editbtn.Click += editbtn_Click;
            // 
            // unamet
            // 
            unamet.Location = new Point(56, 111);
            unamet.Name = "unamet";
            unamet.Size = new Size(236, 23);
            unamet.TabIndex = 29;
            // 
            // uphone
            // 
            uphone.AutoSize = true;
            uphone.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            uphone.Location = new Point(56, 217);
            uphone.Name = "uphone";
            uphone.Size = new Size(95, 19);
            uphone.TabIndex = 30;
            uphone.Text = "PHONE NO.";
            // 
            // uphonet
            // 
            uphonet.Location = new Point(56, 237);
            uphonet.Name = "uphonet";
            uphonet.Size = new Size(236, 23);
            uphonet.TabIndex = 31;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientActiveCaption;
            panel2.Controls.Add(upass);
            panel2.Controls.Add(upasst);
            panel2.Controls.Add(uphonet);
            panel2.Controls.Add(uphone);
            panel2.Controls.Add(unamet);
            panel2.Controls.Add(editbtn);
            panel2.Controls.Add(uemail);
            panel2.Controls.Add(uemailt);
            panel2.Controls.Add(uname);
            panel2.Controls.Add(uid);
            panel2.Controls.Add(uidt);
            panel2.Controls.Add(exitbtn);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(233, -4);
            panel2.Name = "panel2";
            panel2.Size = new Size(593, 479);
            panel2.TabIndex = 7;
            // 
            // upass
            // 
            upass.AutoSize = true;
            upass.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            upass.Location = new Point(54, 150);
            upass.Name = "upass";
            upass.Size = new Size(93, 19);
            upass.TabIndex = 33;
            upass.Text = "PASSWORD";
            // 
            // upasst
            // 
            upasst.Location = new Point(56, 172);
            upasst.Name = "upasst";
            upasst.Size = new Size(236, 23);
            upasst.TabIndex = 32;
            // 
            // UserProfile
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(825, 476);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Name = "UserProfile";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UserInfo";
            Load += UserProfile_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Button logoutbtn;
        private Button userprfilebtn;
        private Button cataloguebtn;
        private Label label1;
        private Label exitbtn;
        private TextBox uidt;
        private Label uid;
        private Label uname;
        private TextBox uemailt;
        private Label uemail;
        private Button editbtn;
        private TextBox unamet;
        private Label uphone;
        private TextBox uphonet;
        private Panel panel2;
        private Label upass;
        private TextBox upasst;
        private Label label8;
        private Label label7;
        private Label label6;
        private Button createbtn;
    }
}