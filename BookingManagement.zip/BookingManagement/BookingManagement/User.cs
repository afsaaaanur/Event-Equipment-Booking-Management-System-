﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BookingManagement
{
    public partial class User : Form
    {
        SqlConnection con = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True");

        public User()
        {
            InitializeComponent();
        }

        //FORM LOAD
        private void User_Load(object sender, EventArgs e)
        {
            LoadUsers();
        }

        //LOAD USERS
        private void LoadUsers()
        {
            try
            {
                con.Open();

                string query = @"
                SELECT UID,
                       UNAME  AS Username,
                       UPHONE AS PhoneNo,
                       UEMAIL AS Email
                FROM USERTB1;
                ";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        //DELETE USER
        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (uidt.Text == "")
            {
                MessageBox.Show("Enter User ID");
                return;
            }
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this user?",
            "Confirm Delete",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning);

                if (result == DialogResult.No)
                    return;

            try
            {
                con.Open();

                string query = "DELETE FROM USERTB1 WHERE UID=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", uidt.Text);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("User Deleted");

                LoadUsers();
                ResetFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //EDIT USER
        private void editbtn_Click(object sender, EventArgs e)
        {
            if (uidt.Text == "")
            {
                MessageBox.Show("Enter User ID");
                return;
            }

            try
            {
                con.Open();

                string query = @"UPDATE USERTB1 
                                 SET UNAME=@name,
                                     UPHONE=@phone,
                                     UEMAIL=@email
                                 WHERE UID=@id";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", uidt.Text);
                cmd.Parameters.AddWithValue("@name", unamet.Text);
                cmd.Parameters.AddWithValue("@phone", uphonet.Text);
                cmd.Parameters.AddWithValue("@email", uemailt.Text);


                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("User Updated");

                LoadUsers();
                ResetFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //GRID CLICK
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                uidt.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                unamet.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                uphonet.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                uemailt.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();

            }
        }

        //RESET
        private void ResetFields()
        {
            uidt.Clear();
            unamet.Clear();
            uphonet.Clear();
            uemailt.Clear();

        }

        //SEARCH
        private void searchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;
          AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
          Integrated Security=True";

                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                
                string query = "SELECT UID, UNAME, UPHONE, UEMAIL FROM USERTB1 " +
                               "WHERE UNAME LIKE @SEARCH + '%' OR CAST(UID AS VARCHAR) LIKE @SEARCH + '%'";

                SqlCommand sq2 = new SqlCommand(query, con);
                SqlDataAdapter sda = new SqlDataAdapter(sq2);
                sq2.Parameters.AddWithValue("@SEARCH", searchfieldt.Text.Trim());

                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No Matching Data Found");
                }

                con.Close();
                searchfieldt.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error!!", "ERROR");
            }
        }


        private void refreshbtn_Click(object sender, EventArgs e)
        {
            LoadUsers();
            searchfieldt.Clear();
        }
        // NAVIGATION BUTTONS
        private void equipmentbtn_Click(object sender, EventArgs e)
        {
            Equipments eq = new Equipments();
            eq.Show();
            this.Hide();   
        }
        

        private void bookingsbtn_Click(object sender, EventArgs e)
        {
            Bookings b = new Bookings();
            b.Show();
            this.Hide();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                 "Are you sure you want to log out?",
                 "Confirm Logout",
                 MessageBoxButtons.YesNo,
                 MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            Login lg = new Login();
            lg.Show();
            this.Hide();
        }
        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
