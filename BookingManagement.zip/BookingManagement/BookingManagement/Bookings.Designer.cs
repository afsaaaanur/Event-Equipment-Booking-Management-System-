﻿namespace BookingManagement
{
    partial class Bookings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            logoutbtn = new Button();
            bookingbtn = new Button();
            userbtn = new Button();
            equipmentbtn = new Button();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            dataGridView1 = new DataGridView();
            deletebtn = new Button();
            searchbtn = new Button();
            label5 = new Label();
            bid = new Label();
            bidt = new TextBox();
            label1 = new Label();
            panel2 = new Panel();
            searchfieldt = new TextBox();
            refreshbtn = new Button();
            bookinglist = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(logoutbtn);
            panel1.Controls.Add(bookingbtn);
            panel1.Controls.Add(userbtn);
            panel1.Controls.Add(equipmentbtn);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(241, 655);
            panel1.TabIndex = 4;
            // 
            // logoutbtn
            // 
            logoutbtn.BackColor = Color.Red;
            logoutbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            logoutbtn.Location = new Point(36, 468);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(174, 43);
            logoutbtn.TabIndex = 11;
            logoutbtn.Text = "Logout";
            logoutbtn.UseVisualStyleBackColor = false;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // bookingbtn
            // 
            bookingbtn.BackColor = Color.ForestGreen;
            bookingbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bookingbtn.Location = new Point(36, 383);
            bookingbtn.Name = "bookingbtn";
            bookingbtn.Size = new Size(174, 43);
            bookingbtn.TabIndex = 10;
            bookingbtn.Text = "Booking";
            bookingbtn.UseVisualStyleBackColor = false;
            // 
            // userbtn
            // 
            userbtn.BackColor = SystemColors.GradientActiveCaption;
            userbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userbtn.Location = new Point(36, 302);
            userbtn.Name = "userbtn";
            userbtn.Size = new Size(174, 43);
            userbtn.TabIndex = 9;
            userbtn.Text = "Users";
            userbtn.UseVisualStyleBackColor = false;
            userbtn.Click += userbtn_Click;
            // 
            // equipmentbtn
            // 
            equipmentbtn.BackColor = SystemColors.GradientActiveCaption;
            equipmentbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            equipmentbtn.Location = new Point(36, 220);
            equipmentbtn.Name = "equipmentbtn";
            equipmentbtn.Size = new Size(174, 43);
            equipmentbtn.TabIndex = 8;
            equipmentbtn.Text = "Equipment";
            equipmentbtn.UseVisualStyleBackColor = false;
            equipmentbtn.Click += equipmentbtn_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(36, 79);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 6;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(52, 120);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 5;
            label7.Text = "Nice Service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(66, 41);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 4;
            label6.Text = "Nice Staff";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonFace;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(3, 242);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(768, 315);
            dataGridView1.TabIndex = 14;
            // 
            // deletebtn
            // 
            deletebtn.BackColor = Color.Red;
            deletebtn.Font = new Font("Century Gothic", 9F);
            deletebtn.ForeColor = SystemColors.ButtonFace;
            deletebtn.Location = new Point(163, 99);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new Size(65, 31);
            deletebtn.TabIndex = 12;
            deletebtn.Text = "Delete";
            deletebtn.UseVisualStyleBackColor = false;
            deletebtn.Click += deletebtn_Click;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.ForestGreen;
            searchbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            searchbtn.ForeColor = SystemColors.ButtonFace;
            searchbtn.Location = new Point(379, 72);
            searchbtn.Name = "searchbtn";
            searchbtn.Size = new Size(111, 41);
            searchbtn.TabIndex = 10;
            searchbtn.Text = "Search";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Red;
            label5.Location = new Point(776, -3);
            label5.Name = "label5";
            label5.Size = new Size(29, 32);
            label5.TabIndex = 6;
            label5.Text = "x";
            label5.Click += label5_Click;
            // 
            // bid
            // 
            bid.AutoSize = true;
            bid.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bid.Location = new Point(55, 83);
            bid.Name = "bid";
            bid.Size = new Size(102, 19);
            bid.TabIndex = 3;
            bid.Text = "BOOKING ID";
            // 
            // bidt
            // 
            bidt.Location = new Point(55, 104);
            bidt.Name = "bidt";
            bidt.Size = new Size(102, 23);
            bidt.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(279, 11);
            label1.Name = "label1";
            label1.Size = new Size(132, 32);
            label1.TabIndex = 0;
            label1.Text = "Bookings";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientActiveCaption;
            panel2.Controls.Add(searchfieldt);
            panel2.Controls.Add(refreshbtn);
            panel2.Controls.Add(bookinglist);
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(deletebtn);
            panel2.Controls.Add(searchbtn);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(bid);
            panel2.Controls.Add(bidt);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(248, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(805, 655);
            panel2.TabIndex = 5;
            // 
            // searchfieldt
            // 
            searchfieldt.Location = new Point(345, 107);
            searchfieldt.Name = "searchfieldt";
            searchfieldt.Size = new Size(182, 23);
            searchfieldt.TabIndex = 23;
            // 
            // refreshbtn
            // 
            refreshbtn.BackColor = Color.ForestGreen;
            refreshbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            refreshbtn.ForeColor = SystemColors.ButtonFace;
            refreshbtn.Location = new Point(591, 72);
            refreshbtn.Name = "refreshbtn";
            refreshbtn.Size = new Size(111, 45);
            refreshbtn.TabIndex = 17;
            refreshbtn.Text = "Refresh";
            refreshbtn.UseVisualStyleBackColor = false;
            refreshbtn.Click += refreshbtn_Click;
            // 
            // bookinglist
            // 
            bookinglist.AutoSize = true;
            bookinglist.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bookinglist.Location = new Point(303, 220);
            bookinglist.Name = "bookinglist";
            bookinglist.Size = new Size(97, 19);
            bookinglist.TabIndex = 16;
            bookinglist.Text = "Booking List";
            // 
            // Bookings
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1065, 679);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Bookings";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Booking";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button logoutbtn;
        private Button bookingbtn;
        private Button userbtn;
        private Button equipmentbtn;
        private Label label8;
        private Label label7;
        private Label label6;
        private DataGridView dataGridView1;
        private Button deletebtn;
        private Button searchbtn;
        private Label label5;
        private Label bid;
        private TextBox bidt;
        private Label label1;
        private Panel panel2;
        private Button refreshbtn;
        private Label bookinglist;
        private TextBox searchfieldt;
    }
}