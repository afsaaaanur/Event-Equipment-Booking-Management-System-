﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookingManagement
{
    public partial class Catalogue : Form
    {

        SqlConnection con = new SqlConnection(
           @"Data Source=(LocalDB)\MSSQLLocalDB;
              AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
              Integrated Security=True");
        public Catalogue()
        {
            InitializeComponent();
            this.Load += Equipments_Load;
        }
        //FORM LOAD
        private void Equipments_Load(object sender, EventArgs e)
        {
            LoadAvailableEquipments();
        }

        //LOAD EQUIPMENTS
        private void LoadAvailableEquipments()
        {
            try
            {
                con.Open();

                string query = @"
                    SELECT 
                        C.CNAME     AS Category,
                        E.ENAME     AS EquipmentName,
                        E.EBRAND    AS Brand,
                        E.ETYPE     AS Type,
                        E.EQUANTITY AS AvailableQuantity
                    FROM EQUIPMENTTB4 E
                    INNER JOIN CATEGORYTB3 C ON E.CID = C.CID
                    WHERE E.EQUANTITY > 0
                ";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //SEARCH BUTTON
        private void searchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(
                   @"Data Source=(LocalDB)\MSSQLLocalDB;
             AttachDbFilename=C:\Users\Subhana\Documents\BookingManagement.mdf;
             Integrated Security=True"))
                {
                    con.Open();

                    string query = @"
                                    SELECT 
                             C.CNAME     AS Category,
                             E.ENAME     AS EquipmentName,
                             E.EBRAND    AS Brand,
                             E.ETYPE     AS Type,
                             E.EQUANTITY AS AvailableQuantity
                             FROM EQUIPMENTTB4 E
                                INNER JOIN CATEGORYTB3 C ON E.CID = C.CID
                                WHERE E.EQUANTITY > 0
                                AND (
                             E.ENAME LIKE @SEARCH
                             OR E.EBRAND LIKE @SEARCH
                             OR E.ETYPE LIKE @SEARCH
                             OR C.CNAME LIKE @SEARCH)";


                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {

                        cmd.Parameters.AddWithValue("@SEARCH", "%" + searchfieldt.Text.Trim() + "%");

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        if (dt.Rows.Count > 0)
                            dataGridView1.DataSource = dt;
                        else
                        {
                            dataGridView1.DataSource = null;
                            MessageBox.Show("No Matching Data Found");
                        }
                    }
                }

                searchfieldt.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error!!\n" + ex.Message, "ERROR");
            }
        }
        //REFRESH BUTTON
        private void refreshbtn_Click(object sender, EventArgs e)
        {
            LoadAvailableEquipments();
            searchfieldt.Clear();
        }

        //NAVIGATION BUTTONS
        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void userprofilebtn_Click(object sender, EventArgs e)
        {
            UserProfile up = new UserProfile();
            up.Show();
            this.Hide();
        }

        private void createbtn_Click(object sender, EventArgs e)
        {
            CreateBookings cb = new CreateBookings();
            cb.Show();
            this.Hide();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to log out?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            Login lg = new Login();
            lg.Show();
            this.Hide();
        }
    }
}
