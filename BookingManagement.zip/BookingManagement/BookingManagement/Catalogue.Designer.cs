﻿namespace BookingManagement
{
    partial class Catalogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button4 = new Button();
            userprofilebtn = new Button();
            button2 = new Button();
            label8 = new Label();
            label7 = new Label();
            createbtn = new Button();
            label6 = new Label();
            dataGridView1 = new DataGridView();
            exitbtn = new Label();
            label1 = new Label();
            panel2 = new Panel();
            refreshbtn = new Button();
            searchfieldt = new TextBox();
            searchbtn = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(button4);
            panel1.Controls.Add(userprofilebtn);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(createbtn);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(241, 655);
            panel1.TabIndex = 4;
            // 
            // button4
            // 
            button4.BackColor = Color.Red;
            button4.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = SystemColors.ButtonFace;
            button4.Location = new Point(36, 540);
            button4.Name = "button4";
            button4.Size = new Size(174, 43);
            button4.TabIndex = 11;
            button4.Text = "Logout";
            button4.UseVisualStyleBackColor = false;
            button4.Click += logoutbtn_Click;
            // 
            // userprofilebtn
            // 
            userprofilebtn.BackColor = SystemColors.GradientActiveCaption;
            userprofilebtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userprofilebtn.Location = new Point(36, 250);
            userprofilebtn.Name = "userprofilebtn";
            userprofilebtn.Size = new Size(174, 43);
            userprofilebtn.TabIndex = 10;
            userprofilebtn.Text = "User Profile";
            userprofilebtn.UseVisualStyleBackColor = false;
            userprofilebtn.Click += userprofilebtn_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.ForestGreen;
            button2.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(36, 319);
            button2.Name = "button2";
            button2.Size = new Size(174, 57);
            button2.TabIndex = 9;
            button2.Text = "Equipments Catalogue";
            button2.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(36, 79);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 6;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(52, 120);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 5;
            label7.Text = "Nice Service";
            // 
            // createbtn
            // 
            createbtn.BackColor = SystemColors.GradientActiveCaption;
            createbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            createbtn.ForeColor = SystemColors.ActiveCaptionText;
            createbtn.Location = new Point(30, 400);
            createbtn.Name = "createbtn";
            createbtn.Size = new Size(180, 40);
            createbtn.TabIndex = 10;
            createbtn.Text = "Create Booking";
            createbtn.UseVisualStyleBackColor = false;
            createbtn.Click += createbtn_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(66, 41);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 4;
            label6.Text = "Nice Staff";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonFace;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(-20, 143);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(825, 512);
            dataGridView1.TabIndex = 14;
            // 
            // exitbtn
            // 
            exitbtn.AutoSize = true;
            exitbtn.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitbtn.ForeColor = Color.Red;
            exitbtn.Location = new Point(776, -3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(29, 32);
            exitbtn.TabIndex = 6;
            exitbtn.Text = "x";
            exitbtn.Click += exitbtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(243, 14);
            label1.Name = "label1";
            label1.Size = new Size(311, 32);
            label1.TabIndex = 0;
            label1.Text = "Equipments Catalogue";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientActiveCaption;
            panel2.Controls.Add(refreshbtn);
            panel2.Controls.Add(searchfieldt);
            panel2.Controls.Add(searchbtn);
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(exitbtn);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(248, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(805, 655);
            panel2.TabIndex = 5;
            // 
            // refreshbtn
            // 
            refreshbtn.BackColor = Color.ForestGreen;
            refreshbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            refreshbtn.Location = new Point(582, 104);
            refreshbtn.Name = "refreshbtn";
            refreshbtn.Size = new Size(108, 33);
            refreshbtn.TabIndex = 16;
            refreshbtn.Text = "Refresh";
            refreshbtn.UseVisualStyleBackColor = false;
            refreshbtn.Click += refreshbtn_Click;
            // 
            // searchfieldt
            // 
            searchfieldt.Location = new Point(303, 110);
            searchfieldt.Name = "searchfieldt";
            searchfieldt.Size = new Size(202, 23);
            searchfieldt.TabIndex = 15;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.ForestGreen;
            searchbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            searchbtn.Location = new Point(341, 71);
            searchbtn.Name = "searchbtn";
            searchbtn.Size = new Size(108, 33);
            searchbtn.TabIndex = 12;
            searchbtn.Text = "Search";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // Catalogue
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1065, 679);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Catalogue";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UserBooking";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button button4;
        private Button userprofilebtn;
        private Button button2;
       // private Button button1;
        private Label label8;
        private Label label7;
        private Label label6;
       // private Button button9;
       // private ComboBox comboBox2;
        private DataGridView dataGridView1;
        private Button createbtn;
      //  private Label label9;
       // private ComboBox comboBox1;
        private Label exitbtn;
       // private Label label4;
       // private Label label3;
      //  private TextBox textBox2;
        private Label label1;
        private Panel panel2;
        private Button searchbtn;
        private TextBox searchfieldt;
        private Button refreshbtn;
    }
}