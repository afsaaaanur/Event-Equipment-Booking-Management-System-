﻿namespace BookingManagement
{
    partial class CreateBookings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            createbtn = new Button();
            logoutbtn = new Button();
            userprofilebtn = new Button();
            cataloguebtn = new Button();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            panel2 = new Panel();
            confirmbtn = new Button();
            editbtn = new Button();
            label3 = new Label();
            quantityt = new NumericUpDown();
            dateTimePicker2 = new DateTimePicker();
            dateTimePicker1 = new DateTimePicker();
            dataGridView1 = new DataGridView();
            addbtn = new Button();
            quantity = new Label();
            equipmentt = new ComboBox();
            label2 = new Label();
            categoryt = new ComboBox();
            category = new Label();
            returnbookdate = new Label();
            startbookdate = new Label();
            label5 = new Label();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)quantityt).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(createbtn);
            panel1.Controls.Add(logoutbtn);
            panel1.Controls.Add(userprofilebtn);
            panel1.Controls.Add(cataloguebtn);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(241, 655);
            panel1.TabIndex = 6;
            // 
            // createbtn
            // 
            createbtn.BackColor = Color.ForestGreen;
            createbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            createbtn.Location = new Point(36, 404);
            createbtn.Name = "createbtn";
            createbtn.Size = new Size(174, 43);
            createbtn.TabIndex = 12;
            createbtn.Text = "Create Booking";
            createbtn.UseVisualStyleBackColor = false;
            // 
            // logoutbtn
            // 
            logoutbtn.BackColor = Color.Red;
            logoutbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            logoutbtn.ForeColor = SystemColors.ButtonFace;
            logoutbtn.Location = new Point(36, 540);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(174, 43);
            logoutbtn.TabIndex = 11;
            logoutbtn.Text = "Logout";
            logoutbtn.UseVisualStyleBackColor = false;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // userprofilebtn
            // 
            userprofilebtn.BackColor = SystemColors.GradientActiveCaption;
            userprofilebtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userprofilebtn.Location = new Point(36, 250);
            userprofilebtn.Name = "userprofilebtn";
            userprofilebtn.Size = new Size(174, 43);
            userprofilebtn.TabIndex = 10;
            userprofilebtn.Text = "User Profile";
            userprofilebtn.UseVisualStyleBackColor = false;
            userprofilebtn.Click += userprofilebtn_Click;
            // 
            // cataloguebtn
            // 
            cataloguebtn.BackColor = SystemColors.GradientActiveCaption;
            cataloguebtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cataloguebtn.Location = new Point(36, 319);
            cataloguebtn.Name = "cataloguebtn";
            cataloguebtn.Size = new Size(174, 62);
            cataloguebtn.TabIndex = 9;
            cataloguebtn.Text = "Equipments Catalogue";
            cataloguebtn.UseVisualStyleBackColor = false;
            cataloguebtn.Click += cataloguebtn_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonFace;
            label8.Location = new Point(36, 79);
            label8.Name = "label8";
            label8.Size = new Size(174, 25);
            label8.TabIndex = 6;
            label8.Text = "Nice Equipment";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(52, 120);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 5;
            label7.Text = "Nice Service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(66, 41);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 4;
            label6.Text = "Nice Staff";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientActiveCaption;
            panel2.Controls.Add(confirmbtn);
            panel2.Controls.Add(editbtn);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(quantityt);
            panel2.Controls.Add(dateTimePicker2);
            panel2.Controls.Add(dateTimePicker1);
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(addbtn);
            panel2.Controls.Add(quantity);
            panel2.Controls.Add(equipmentt);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(categoryt);
            panel2.Controls.Add(category);
            panel2.Controls.Add(returnbookdate);
            panel2.Controls.Add(startbookdate);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(248, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(805, 655);
            panel2.TabIndex = 7;
            // 
            // confirmbtn
            // 
            confirmbtn.BackColor = Color.ForestGreen;
            confirmbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            confirmbtn.ForeColor = SystemColors.ButtonFace;
            confirmbtn.Location = new Point(178, 221);
            confirmbtn.Name = "confirmbtn";
            confirmbtn.Size = new Size(111, 41);
            confirmbtn.TabIndex = 34;
            confirmbtn.Text = "Confirm";
            confirmbtn.UseVisualStyleBackColor = false;
            confirmbtn.Click += confirmbtn_Click;
            // 
            // editbtn
            // 
            editbtn.BackColor = Color.ForestGreen;
            editbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            editbtn.ForeColor = SystemColors.ButtonFace;
            editbtn.Location = new Point(306, 221);
            editbtn.Name = "editbtn";
            editbtn.Size = new Size(111, 41);
            editbtn.TabIndex = 33;
            editbtn.Text = "Edit";
            editbtn.UseVisualStyleBackColor = false;
            editbtn.Click += editbtn_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(318, 287);
            label3.Name = "label3";
            label3.Size = new Size(145, 19);
            label3.TabIndex = 32;
            label3.Text = "List of All Bookings";
            // 
            // quantityt
            // 
            quantityt.Location = new Point(656, 119);
            quantityt.Name = "quantityt";
            quantityt.Size = new Size(120, 23);
            quantityt.TabIndex = 8;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(11, 192);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(200, 23);
            dateTimePicker2.TabIndex = 31;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(11, 120);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 30;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonFace;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(3, 309);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(802, 346);
            dataGridView1.TabIndex = 29;
            // 
            // addbtn
            // 
            addbtn.BackColor = Color.ForestGreen;
            addbtn.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addbtn.ForeColor = SystemColors.ButtonFace;
            addbtn.Location = new Point(437, 221);
            addbtn.Name = "addbtn";
            addbtn.Size = new Size(111, 41);
            addbtn.TabIndex = 28;
            addbtn.Text = "Add";
            addbtn.UseVisualStyleBackColor = false;
            addbtn.Click += addbtn_Click;
            // 
            // quantity
            // 
            quantity.AutoSize = true;
            quantity.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            quantity.Location = new Point(690, 79);
            quantity.Name = "quantity";
            quantity.Size = new Size(74, 19);
            quantity.TabIndex = 25;
            quantity.Text = "Quantity";
            // 
            // equipmentt
            // 
            equipmentt.Font = new Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            equipmentt.ForeColor = SystemColors.WindowFrame;
            equipmentt.FormattingEnabled = true;
            equipmentt.Location = new Point(453, 120);
            equipmentt.Name = "equipmentt";
            equipmentt.Size = new Size(166, 24);
            equipmentt.TabIndex = 24;
            equipmentt.Text = "Select Equipment";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(453, 85);
            label2.Name = "label2";
            label2.Size = new Size(143, 19);
            label2.TabIndex = 23;
            label2.Text = "Select Equipment";
            // 
            // categoryt
            // 
            categoryt.Font = new Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            categoryt.ForeColor = SystemColors.WindowFrame;
            categoryt.FormattingEnabled = true;
            categoryt.Location = new Point(251, 121);
            categoryt.Name = "categoryt";
            categoryt.Size = new Size(166, 24);
            categoryt.TabIndex = 22;
            categoryt.Text = "Select Category";
            // 
            // category
            // 
            category.AutoSize = true;
            category.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            category.Location = new Point(251, 85);
            category.Name = "category";
            category.Size = new Size(131, 19);
            category.TabIndex = 21;
            category.Text = "Select Category";
            // 
            // returnbookdate
            // 
            returnbookdate.AutoSize = true;
            returnbookdate.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            returnbookdate.Location = new Point(29, 157);
            returnbookdate.Name = "returnbookdate";
            returnbookdate.Size = new Size(122, 19);
            returnbookdate.TabIndex = 19;
            returnbookdate.Text = "Returning Date";
            // 
            // startbookdate
            // 
            startbookdate.AutoSize = true;
            startbookdate.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            startbookdate.Location = new Point(39, 83);
            startbookdate.Name = "startbookdate";
            startbookdate.Size = new Size(112, 19);
            startbookdate.TabIndex = 17;
            startbookdate.Text = "Booking Date";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Red;
            label5.Location = new Point(776, -3);
            label5.Name = "label5";
            label5.Size = new Size(29, 32);
            label5.TabIndex = 6;
            label5.Text = "x";
            label5.Click += label5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(49, 23);
            label1.Name = "label1";
            label1.Size = new Size(210, 32);
            label1.TabIndex = 0;
            label1.Text = "CreateBooking";
            // 
            // CreateBookings
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1065, 679);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CreateBookings";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BookDetails";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)quantityt).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button logoutbtn;
        private Button userprofilebtn;
        private Button cataloguebtn;
        private Label label8;
        private Label label7;
        private Label label6;
        private Panel panel2;
        private Label label5;
        private Label label1;
        private Label startbookdate;
        private Label returnbookdate;
        private ComboBox categoryt;
        private Label category;
        private ComboBox equipmentt;
        private Label label2;
        private Button addbtn;
        private Label quantity;
        private DataGridView dataGridView1;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private NumericUpDown quantityt;
        private Label label3;
        private Button createbtn;
        private Button editbtn;
        private Button confirmbtn;
    }
}